Ссылка на репозиторий с фронтендом: https://github.com/Zabava2/Frontend-pindie.git

Ссылка на домен фронтенда: https://frontendpindie.nomoredomainswork.ru/

IP-адрес:158.160.128.54
